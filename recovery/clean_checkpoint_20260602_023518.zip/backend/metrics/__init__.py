"""Canonical runtime metrics."""
