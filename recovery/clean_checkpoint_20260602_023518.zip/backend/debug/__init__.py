"""Debug and audit utilities."""
