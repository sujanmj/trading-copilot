"""
Shared Telegram analysis response formatting (Stage 45TG5).
"""

from __future__ import annotations

import re
from typing import Any

RESEARCH_FOOTER = 'Research only. You decide and place trades manually.'
SHADOW_DISCLAIMER = RESEARCH_FOOTER
BLOCKED_TRADE_RESPONSE = (
    "I can't place orders. Try /today, /tomorrow, /aihub scan, or /ask ai <question>."
)
TRADE_EXECUTION_PERMANENTLY_DISABLED = True
DECISION_ENGINE_PENDING = (
    'For final one-stock recommendation, Stock Decision Engine is pending.'
)

BLOCKED_TRADE_COMMANDS = frozenset({
    'buy', 'sell', 'execute', 'place_order', 'trade', 'auto_trade',
})

_FOOTER_PHRASES = (
    RESEARCH_FOOTER,
    'Shadow mode only — not trade execution.',
    'Shadow mode only - not trade execution.',
    'Trade execution permanently disabled.',
    'Blocked forever.',
)

_STAGE_MARKER_RE = re.compile(
    r'(TELEGRAM_STAGE|GUI_BUILD_STAGE|BACKEND_STAGE|QA_STAGE)[_\w]*',
    re.IGNORECASE,
)

AIHUB_FULL_TABS = (
    'brain', 'govt', 'scan', 'market', 'global', 'news', 'tv', 'reddit', 'calib', 'journal',
)


def strip_stage_markers(text: str) -> str:
    """Remove internal stage markers and repeated safety footers from outbound Telegram text."""
    body = str(text or '')
    body = re.sub(
        r'<code>\s*(TELEGRAM_STAGE|GUI_BUILD_STAGE|BACKEND_STAGE|QA_STAGE)[_\w]*\s*</code>\s*',
        '',
        body,
        flags=re.IGNORECASE,
    )
    body = _STAGE_MARKER_RE.sub('', body)
    lines: list[str] = []
    for line in body.splitlines():
        stripped = line.strip()
        if not stripped:
            lines.append('')
            continue
        lower = stripped.lower()
        if any(phrase.lower() in lower for phrase in _FOOTER_PHRASES):
            continue
        if _STAGE_MARKER_RE.search(stripped):
            continue
        lines.append(line)
    while lines and not lines[-1].strip():
        lines.pop()
    return '\n'.join(lines).strip()


def with_shadow_disclaimer(text: str) -> str:
    """Legacy name — sanitizes only; no footer is appended."""
    return strip_stage_markers(text)


def format_blocked_trade_with_symbol(cmd: str, args: str) -> str:
    return BLOCKED_TRADE_RESPONSE


def format_aihub_menu() -> str:
    return (
        '<b>🧭 AI Hub menu</b>\n'
        'Tabs: brain · govt · scan · market · global · news · tv · reddit · calib · journal\n'
        'Use /aihub &lt;tab&gt; — e.g. /aihub scan\n'
        'Use /aihub full for the compact all-tabs summary'
    )


def _load_actionable() -> dict[str, Any]:
    from backend.utils.config import DATA_DIR
    import json
    from pathlib import Path

    pack_path = DATA_DIR / 'daily_report_pack_latest.json'
    fc_path = DATA_DIR / 'final_confidence_report.json'
    pack = {}
    fc = {}
    if pack_path.is_file():
        try:
            pack = json.loads(pack_path.read_text(encoding='utf-8'))
        except (OSError, json.JSONDecodeError):
            pack = {}
    if fc_path.is_file():
        try:
            fc = json.loads(fc_path.read_text(encoding='utf-8'))
        except (OSError, json.JSONDecodeError):
            fc = {}
    from backend.analytics.aihub_tab_payloads import _build_actionable_candidates

    return _build_actionable_candidates(pack if isinstance(pack, dict) else {}, fc)


def format_today_tomorrow(which: str) -> str:
    label = 'Today' if which == 'today' else 'Tomorrow'
    actionable = _load_actionable()
    buy_rows = actionable.get('buy_candidate') or []
    watch_rows = actionable.get('watch_for_entry') or []

    lines = [f'<b>📋 {label}</b>']

    if buy_rows:
        lines.append('<b>Confirmed BUY candidate (from current filters):</b>')
        for idx, row in enumerate(buy_rows[:3], 1):
            if isinstance(row, dict):
                ticker = row.get('ticker') or row.get('symbol') or '?'
                lines.append(f'{idx}. {ticker}')
    else:
        lines.append('No confirmed BUY candidate from current filters.')
        lines.append('')
        lines.append('<b>Best watch-for-entry:</b>')
        if watch_rows:
            for idx, row in enumerate(watch_rows[:3], 1):
                if isinstance(row, dict):
                    ticker = row.get('ticker') or '?'
                    lines.append(f'{idx}. {ticker}')
        else:
            lines.append('• No watch candidates in cache.')

    lines.extend([
        '',
        '<b>Need confirmation:</b>',
        '- price strength',
        '- volume support',
        '- market not stale',
        '',
        DECISION_ENGINE_PENDING,
    ])
    return '\n'.join(lines)


def _ticker_from_row(row: dict[str, Any]) -> str:
    return str(row.get('ticker') or row.get('symbol') or '?').upper()


def format_aihub_payload(tab: str, payload: dict[str, Any]) -> str:
    key = str(tab or '').strip().lower()
    summary = payload.get('summary') or {}
    items = payload.get('items') or []
    lines = [
        f'<b>AI Hub · {key}</b>',
        f"Source: {payload.get('source', '—')} · cache age: {payload.get('cache_age_seconds', 0) // 60}m",
    ]
    if key == 'brain':
        for row in items[:5]:
            if isinstance(row, dict):
                lines.append(f"• {str(row.get('title') or row.get('summary') or row.get('text') or '—')[:140]}")
    elif key == 'scan':
        lines.append(
            f"Live: {summary.get('live_scanner_count', 0)} · "
            f"watchlist: {summary.get('watchlist_count', 0)} · "
            f"memory: {summary.get('memory_signal_count', 0)}"
        )
        for row in items[:8]:
            if isinstance(row, dict):
                ticker = row.get('ticker') or '?'
                price = row.get('price')
                if price is not None:
                    try:
                        if float(price) <= 0:
                            continue
                    except (TypeError, ValueError):
                        pass
                lines.append(f"• {ticker} · {row.get('strength') or 'SIGNAL'}")
    elif key in ('news', 'tv', 'reddit'):
        for row in items[:8]:
            if isinstance(row, dict):
                title = str(row.get('title') or row.get('headline') or '—')[:120]
                lines.append(f"• {title}")
        if not items:
            empty = summary.get('empty_message') or 'No cached items.'
            lines.append(str(empty))
    elif key == 'calib':
        fc = summary.get('final_confidence') or {}
        cal = summary.get('confidence_calibration') or {}
        if isinstance(fc, dict):
            lines.append(
                f"Final confidence — watch: {fc.get('watch', '?')} · avoid: {fc.get('avoid', '?')}"
            )
        recs = summary.get('calibration_recommendations') or cal.get('recommendations') or []
        for rec in recs[:5]:
            if isinstance(rec, dict):
                lines.append(f"• {str(rec.get('message') or rec.get('title') or rec)[:120]}")
            elif isinstance(rec, str):
                lines.append(f"• {rec[:120]}")
    elif key == 'journal':
        hist = summary.get('history') or {}
        lines.append(f"Journal predictions: {hist.get('count', len(items))}")
        for row in items[:6]:
            if isinstance(row, dict):
                ticker = row.get('ticker') or row.get('symbol') or '?'
                lines.append(f"• {ticker}")
    else:
        for row in items[:6]:
            if isinstance(row, dict):
                label = str(row.get('label') or row.get('title') or row.get('ticker') or '—')[:100]
                lines.append(f"• {label}")

    warnings = payload.get('warnings') or []
    if warnings:
        lines.append(f"Warnings: {', '.join(str(w) for w in warnings[:4])}")
    return strip_stage_markers('\n'.join(lines))


def format_aihub_full(payloads: dict[str, dict[str, Any]]) -> str:
    lines = ['<b>🧭 AI Hub Full Summary</b>']

    brain = payloads.get('brain') or {}
    brain_summary = brain.get('summary') or {}
    brain_items = brain.get('items') or []
    actionable = brain_summary.get('actionable_candidates') or {}
    lines.append('<b>🧠 Brain</b>')
    if brain_items:
        row = brain_items[0]
        if isinstance(row, dict):
            sig = str(row.get('title') or row.get('summary') or row.get('text') or '—')[:120]
            lines.append(f'- {sig}')
    else:
        watch_n = len(actionable.get('watch_for_entry') or [])
        lines.append(f'- {watch_n} watch candidates' if watch_n else '- no brain signal cached')

    govt = payloads.get('govt') or {}
    govt_items = govt.get('items') or []
    govt_summary = govt.get('summary') or {}
    lines.append('<b>🏛 Govt</b>')
    if govt_items:
        row = govt_items[0]
        if isinstance(row, dict):
            lines.append(f"- {str(row.get('title') or row.get('headline') or row.get('summary') or '—')[:120]}")
    else:
        risk = govt_summary.get('top_risk') or govt_summary.get('policy_risk') or 'clean / no cached govt items'
        lines.append(f'- {risk}')

    scan = payloads.get('scan') or {}
    scan_summary = scan.get('summary') or {}
    scan_items = scan.get('items') or []
    live_scanner = scan.get('live_scanner') or []
    watchlist = scan.get('watchlist_candidates') or []
    lines.append('<b>📈 Scan</b>')
    lines.append(f"- live count: {scan_summary.get('live_scanner_count', len(live_scanner))}")
    scanner_names = [_ticker_from_row(r) for r in live_scanner[:3] if isinstance(r, dict)]
    watch_names = [_ticker_from_row(r) for r in watchlist[:3] if isinstance(r, dict)]
    if not scanner_names:
        scanner_names = [_ticker_from_row(r) for r in scan_items[:3] if isinstance(r, dict)]
    lines.append(f"- top scanner: {', '.join(scanner_names) if scanner_names else '—'}")
    lines.append(f"- top watchlist: {', '.join(watch_names) if watch_names else '—'}")

    market = payloads.get('market') or {}
    market_summary = market.get('summary') or {}
    mode = market.get('market_mode') or market_summary.get('market_mode') or 'RESEARCH_MODE'
    stale = market_summary.get('stale') or market_summary.get('is_stale')
    lines.append('<b>📊 Market</b>')
    lines.append(f'- mode: {mode}')
    lines.append(f"- {'stale' if stale else 'fresh'}")
    india = market_summary.get('india_context') or market_summary.get('context') or {}
    us_ctx = market_summary.get('us_context') or market_summary.get('global_context') or {}
    if isinstance(india, dict) and india:
        lines.append(f"- India: {str(india.get('headline') or india.get('status') or '—')[:80]}")
    if isinstance(us_ctx, dict) and us_ctx:
        lines.append(f"- US: {str(us_ctx.get('headline') or us_ctx.get('status') or '—')[:80]}")

    global_p = payloads.get('global') or {}
    global_summary = global_p.get('summary') or {}
    lines.append('<b>🌐 Global</b>')
    risk = global_summary.get('global_risk') or global_summary.get('risk_tone') or global_summary.get('tone')
    lines.append(f"- top risk: {risk or '—'}")
    commodities = global_summary.get('commodity_impacts') or global_summary.get('commodities') or []
    if isinstance(commodities, list) and commodities:
        parts = []
        for row in commodities[:3]:
            if isinstance(row, dict):
                parts.append(f"{row.get('commodity', '?')}: {row.get('stance', 'WATCH')}")
        if parts:
            lines.append(f"- commodities: {', '.join(parts)}")

    news = payloads.get('news') or {}
    news_items = news.get('items') or []
    lines.append('<b>📰 News</b>')
    if news_items:
        for row in news_items[:3]:
            if isinstance(row, dict):
                lines.append(f"- {str(row.get('title') or row.get('headline') or '—')[:100]}")
    else:
        lines.append('- no cached headlines')

    tv = payloads.get('tv') or {}
    tv_items = tv.get('items') or []
    lines.append('<b>📺 TV</b>')
    if tv_items:
        for row in tv_items[:3]:
            if isinstance(row, dict):
                lines.append(f"- {str(row.get('title') or row.get('headline') or '—')[:100]}")
    else:
        lines.append('- empty')

    reddit = payloads.get('reddit') or {}
    reddit_items = reddit.get('items') or []
    lines.append('<b>🤖 Reddit</b>')
    if reddit_items:
        for row in reddit_items[:3]:
            if isinstance(row, dict):
                lines.append(f"- {str(row.get('title') or row.get('headline') or '—')[:100]}")
    else:
        lines.append('- cache empty')

    calib = payloads.get('calib') or {}
    cal_summary = calib.get('summary') or {}
    cal = cal_summary.get('confidence_calibration') or {}
    if isinstance(cal, dict) and cal.get('summary'):
        cal = cal.get('summary') or cal
    recs = cal_summary.get('calibration_recommendations') or cal.get('recommendations') or []
    lines.append('<b>📊 Calib</b>')
    lines.append(f"- live resolved: {cal.get('live_resolved', cal.get('resolved_live', '—'))}")
    lines.append(f"- historical resolved: {cal.get('historical_resolved', cal.get('resolved_historical', '—'))}")
    if recs:
        first = recs[0]
        msg = first.get('message') if isinstance(first, dict) else str(first)
        lines.append(f"- warning: {str(msg)[:100]}")
    else:
        lines.append('- no calibration warnings')

    journal = payloads.get('journal') or {}
    journal_summary = journal.get('summary') or {}
    top_watch = journal_summary.get('top_watch') or []
    failed = journal_summary.get('failed_strong_warnings') or []
    lines.append('<b>📜 Journal</b>')
    lines.append(f"- mode: {journal.get('market_mode') or journal_summary.get('market_mode') or '—'}")
    if top_watch:
        names = [_ticker_from_row(r) for r in top_watch[:3] if isinstance(r, dict)]
        lines.append(f"- top watch: {', '.join(names)}")
    else:
        lines.append('- top watch: —')
    lines.append(f"- risk notes: {len(failed) if isinstance(failed, list) else 0}")

    lines.extend([
        '',
        'Use /today or /tomorrow for the short action list.',
    ])
    return strip_stage_markers('\n'.join(lines))


def format_status_text() -> str:
    lines = ['<b>📡 Status</b>']
    try:
        from backend.utils.config import IS_LOCAL_DEV, LOCAL_ONLY, DISABLE_TELEGRAM_LISTENER, DISABLE_TELEGRAM_SENDS
        from backend.utils.telegram_guard import is_telegram_listener_enabled, is_telegram_send_enabled

        mode = 'local' if (LOCAL_ONLY or IS_LOCAL_DEV) else 'railway/production'
        lines.append(f'Mode: <code>{mode}</code>')
        lines.append(f'Telegram listener: {"enabled" if is_telegram_listener_enabled() else "disabled"}')
        lines.append(f'Telegram sends: {"enabled" if is_telegram_send_enabled() else "disabled"}')
        if DISABLE_TELEGRAM_LISTENER:
            lines.append('DISABLE_TELEGRAM_LISTENER=1')
        if DISABLE_TELEGRAM_SENDS:
            lines.append('DISABLE_TELEGRAM_SENDS=1')
    except Exception:
        lines.append('Mode: unknown (config unavailable)')

    try:
        from backend.runtime.runtime_state import get_runtime_state

        rs = get_runtime_state(force_refresh=False)
        market_mode = rs.get('market_mode') or rs.get('active_mode') or '—'
        report_time = rs.get('report_generated_at') or rs.get('intelligence_timestamp') or '—'
        lines.append(f'Market mode: <code>{market_mode}</code>')
        lines.append(f'Latest report: {report_time}')
    except Exception:
        from backend.utils.config import DATA_DIR
        pack_path = DATA_DIR / 'daily_report_pack_latest.json'
        if pack_path.is_file():
            lines.append(f'Latest report file mtime available ({pack_path.name})')
        else:
            lines.append('Latest report: unavailable')

    try:
        from backend.telegram.lazy_command_runner import QA_REPORT_PATH, _cache_age_minutes, _load_json

        qa = _load_json(QA_REPORT_PATH)
        if qa:
            status = 'ok' if qa.get('ok') is True or qa.get('ready') is True else str(qa.get('status') or 'unknown')
            age = _cache_age_minutes(QA_REPORT_PATH)
            age_txt = f'{age}m ago' if age >= 0 else 'unknown age'
            lines.append(f'Last QA: <code>{status}</code> ({age_txt})')
        else:
            lines.append('Last QA: no report cached')
    except Exception:
        lines.append('Last QA: unavailable')

    return strip_stage_markers('\n'.join(lines))
