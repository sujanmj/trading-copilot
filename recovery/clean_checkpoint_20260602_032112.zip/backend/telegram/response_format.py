"""
Shared Telegram analysis response formatting (Stage 45TG5).
"""

from __future__ import annotations

import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

RESEARCH_FOOTER = 'Research only. You decide and place trades manually.'
SHADOW_DISCLAIMER = RESEARCH_FOOTER
BLOCKED_TRADE_RESPONSE = (
    "I can't place orders. Try /today, /tomorrow, /aihub scan, or /ask ai <question>."
)
TRADE_EXECUTION_PERMANENTLY_DISABLED = True

BLOCKED_TRADE_COMMANDS = frozenset({
    'buy', 'sell', 'execute', 'place_order', 'trade', 'auto_trade',
})

_FOOTER_PHRASES = (
    RESEARCH_FOOTER,
    'Shadow mode only — not trade execution.',
    'Shadow mode only - not trade execution.',
    'Trade execution permanently disabled.',
    'Blocked forever.',
)

_STAGE_MARKER_RE = re.compile(
    r'(TELEGRAM_STAGE|GUI_BUILD_STAGE|BACKEND_STAGE|QA_STAGE)[_\w]*',
    re.IGNORECASE,
)

AIHUB_FULL_TABS = (
    'brain', 'govt', 'scan', 'market', 'global', 'news', 'tv', 'reddit', 'calib', 'journal',
)

STALE_CACHE_HOURS = 24
DATA_ACCURACY_STAGE_MARKER = 'TELEGRAM_STAGE_45B2_DATA_ACCURACY_POLISH'
ACTION_PLAN_STAGE_MARKER = 'TELEGRAM_STAGE_45B3_ACTION_PLAN_BRAIN_FULL_ONLY'


def format_cache_age_label(
    age_minutes: int,
    *,
    timestamp: str | None = None,
    stale_hours: int = STALE_CACHE_HOURS,
) -> str:
    """Human-readable cache age — avoids huge minute values in Telegram output."""
    if age_minutes < 0:
        return 'unknown age'
    if age_minutes >= stale_hours * 60:
        if timestamp:
            return f'stale cache · last report {timestamp}'
        return 'stale cache'
    if age_minutes < 60:
        return f'{age_minutes}m'
    hours = age_minutes // 60
    if hours < stale_hours:
        return f'{hours}h'
    if timestamp:
        return f'stale cache · last report {timestamp}'
    return 'stale cache'


def file_timestamp_iso(path: Path) -> str | None:
    if not path.is_file():
        return None
    try:
        mtime = datetime.fromtimestamp(path.stat().st_mtime, tz=timezone.utc)
        return mtime.replace(microsecond=0).isoformat()
    except OSError:
        return None


def format_memory_outcome_line(row: dict[str, Any]) -> str:
    ticker = str(row.get('ticker') or row.get('symbol') or '?').upper()
    outcome = (
        row.get('resolved_as')
        or row.get('outcome')
        or row.get('result')
        or row.get('status')
        or '—'
    )
    outcome_txt = str(outcome).upper()
    move = row.get('actual_move')
    if move is not None:
        try:
            return f'• {ticker} — {outcome_txt} — {float(move):+.2f}%'
        except (TypeError, ValueError):
            return f'• {ticker} — {outcome_txt} — {move}'
    return f'• {ticker} — {outcome_txt}'


def format_memory_win_rate(overall: dict[str, Any]) -> str:
    wins = int(overall.get('wins') or 0)
    losses = int(overall.get('losses') or 0)
    try:
        from backend.metrics.canonical_metrics import format_win_rate_display

        display = format_win_rate_display(wins, losses, min_sample=1)
        return str(display.get('win_rate_display') or '—')
    except Exception:
        win_rate = overall.get('win_rate')
        if isinstance(win_rate, (int, float)):
            pct = float(win_rate) * 100 if float(win_rate) <= 1 else float(win_rate)
            return f'{pct:.1f}%'
        if wins + losses > 0:
            return f'{(wins / (wins + losses)) * 100:.1f}%'
        return '—'


def resolve_global_risk_text(global_p: dict[str, Any]) -> str:
    summary = global_p.get('summary') or {}
    for key in ('global_risk', 'risk_tone', 'tone'):
        val = summary.get(key)
        if val is not None and str(val).strip() not in ('', '—', '-'):
            return str(val).strip()[:120]

    for row in global_p.get('items') or []:
        if not isinstance(row, dict):
            continue
        if str(row.get('classification') or '') == 'macro_context' and row.get('title'):
            return str(row['title']).strip()[:120]

    commodities = summary.get('commodity_impacts') or summary.get('commodities') or []
    if isinstance(commodities, list):
        parts: list[str] = []
        for row in commodities[:3]:
            if isinstance(row, dict):
                parts.append(f"{row.get('commodity', '?')}: {row.get('stance', 'WATCH')}")
        if parts:
            return ', '.join(parts)
    return 'monitor macro headlines'


def strip_stage_markers(text: str) -> str:
    """Remove internal stage markers and repeated safety footers from outbound Telegram text."""
    body = str(text or '')
    body = re.sub(
        r'<code>\s*(TELEGRAM_STAGE|GUI_BUILD_STAGE|BACKEND_STAGE|QA_STAGE)[_\w]*\s*</code>\s*',
        '',
        body,
        flags=re.IGNORECASE,
    )
    body = _STAGE_MARKER_RE.sub('', body)
    lines: list[str] = []
    for line in body.splitlines():
        stripped = line.strip()
        if not stripped:
            lines.append('')
            continue
        lower = stripped.lower()
        if any(phrase.lower() in lower for phrase in _FOOTER_PHRASES):
            continue
        if _STAGE_MARKER_RE.search(stripped):
            continue
        lines.append(line)
    while lines and not lines[-1].strip():
        lines.pop()
    return '\n'.join(lines).strip()


def with_shadow_disclaimer(text: str) -> str:
    """Legacy name — sanitizes only; no footer is appended."""
    return strip_stage_markers(text)


def format_blocked_trade_with_symbol(cmd: str, args: str) -> str:
    return BLOCKED_TRADE_RESPONSE


def format_aihub_menu() -> str:
    return (
        '<b>🧭 AI Hub menu</b>\n'
        'Tabs: brain · govt · scan · market · global · news · tv · reddit · calib · journal\n'
        'Use /aihub &lt;tab&gt; — e.g. /aihub scan\n'
        'Use /aihub full for the compact all-tabs summary'
    )


def _load_actionable() -> dict[str, Any]:
    from backend.utils.config import DATA_DIR
    import json
    from pathlib import Path

    pack_path = DATA_DIR / 'daily_report_pack_latest.json'
    fc_path = DATA_DIR / 'final_confidence_report.json'
    pack = {}
    fc = {}
    if pack_path.is_file():
        try:
            pack = json.loads(pack_path.read_text(encoding='utf-8'))
        except (OSError, json.JSONDecodeError):
            pack = {}
    if fc_path.is_file():
        try:
            fc = json.loads(fc_path.read_text(encoding='utf-8'))
        except (OSError, json.JSONDecodeError):
            fc = {}
    from backend.analytics.aihub_tab_payloads import _build_actionable_candidates

    return _build_actionable_candidates(pack if isinstance(pack, dict) else {}, fc)


def format_stock_decision_telegram(mode: str) -> str:
    from backend.analytics.stock_decision_engine import build_stock_decision

    payload = build_stock_decision(mode=mode)
    if payload.get('ok') is not True:
        label = 'Today' if mode == 'today' else mode.capitalize()
        return (
            f'<b>📋 {label}</b>\n'
            f"No decision available — {payload.get('message') or payload.get('error') or 'refresh reports'}."
        )
    return strip_stage_markers(str(payload.get('telegram_message') or ''))


def format_today_tomorrow(which: str) -> str:
    mode = 'today' if which == 'today' else 'tomorrow'
    return format_stock_decision_telegram(mode)


def format_why_ticker(ticker: str, *, mode: str = 'today') -> str:
    from backend.analytics.stock_decision_engine import lookup_ticker_in_decision

    result = lookup_ticker_in_decision(ticker, mode=mode)
    if result.get('ok') is not True:
        return f"Why lookup failed — {result.get('error') or result.get('message') or 'unknown'}."
    if not result.get('found'):
        return f"No decision data for <code>{ticker.upper()}</code> in latest {mode} payload."

    row = result.get('breakdown') or {}
    sym = row.get('ticker') or ticker.upper()
    action = str(row.get('action') or '—').replace('_', ' ')
    lines = [
        f'<b>Why {sym}</b> ({mode})',
        f'Action: {action} · Score: {row.get("score", "—")} · Confidence: {row.get("confidence", "—")}',
        '',
        '<b>Why:</b>',
    ]
    for item in row.get('why') or []:
        lines.append(f'• {item}')
    if row.get('risk'):
        lines.extend(['', '<b>Risk:</b>'])
        for item in row.get('risk') or []:
            lines.append(f'• {item}')
    if row.get('confirmation_needed'):
        lines.extend(['', '<b>Wait for:</b>'])
        for item in row.get('confirmation_needed') or []:
            lines.append(f'• {item}')
    if row.get('invalid_if'):
        lines.extend(['', '<b>Invalid if:</b>'])
        for item in row.get('invalid_if') or []:
            lines.append(f'• {item}')
    supports = row.get('supports') or []
    if supports:
        lines.extend(['', f"Supports: {', '.join(str(s) for s in supports)}"])
    return strip_stage_markers('\n'.join(lines))


def _ticker_from_row(row: dict[str, Any]) -> str:
    return str(row.get('ticker') or row.get('symbol') or '?').upper()


def format_aihub_payload(tab: str, payload: dict[str, Any]) -> str:
    key = str(tab or '').strip().lower()
    summary = payload.get('summary') or {}
    items = payload.get('items') or []
    lines = [
        f'<b>AI Hub · {key}</b>',
        f"Source: {payload.get('source', '—')} · cache age: {payload.get('cache_age_seconds', 0) // 60}m",
    ]
    if key == 'brain':
        for row in items[:5]:
            if isinstance(row, dict):
                lines.append(f"• {str(row.get('title') or row.get('summary') or row.get('text') or '—')[:140]}")
    elif key == 'scan':
        lines.append(
            f"Live: {summary.get('live_scanner_count', 0)} · "
            f"watchlist: {summary.get('watchlist_count', 0)} · "
            f"memory: {summary.get('memory_signal_count', 0)}"
        )
        for row in items[:8]:
            if isinstance(row, dict):
                ticker = row.get('ticker') or '?'
                price = row.get('price')
                if price is not None:
                    try:
                        if float(price) <= 0:
                            continue
                    except (TypeError, ValueError):
                        pass
                lines.append(f"• {ticker} · {row.get('strength') or 'SIGNAL'}")
    elif key in ('news', 'tv', 'reddit'):
        for row in items[:8]:
            if isinstance(row, dict):
                title = str(row.get('title') or row.get('headline') or '—')[:120]
                lines.append(f"• {title}")
        if not items:
            empty = summary.get('empty_message') or 'No cached items.'
            lines.append(str(empty))
    elif key == 'calib':
        fc = summary.get('final_confidence') or {}
        cal = summary.get('confidence_calibration') or {}
        if isinstance(fc, dict):
            lines.append(
                f"Final confidence — watch: {fc.get('watch', '?')} · avoid: {fc.get('avoid', '?')}"
            )
        recs = summary.get('calibration_recommendations') or cal.get('recommendations') or []
        for rec in recs[:5]:
            if isinstance(rec, dict):
                lines.append(f"• {str(rec.get('message') or rec.get('title') or rec)[:120]}")
            elif isinstance(rec, str):
                lines.append(f"• {rec[:120]}")
    elif key == 'journal':
        hist = summary.get('history') or {}
        lines.append(f"Journal predictions: {hist.get('count', len(items))}")
        for row in items[:6]:
            if isinstance(row, dict):
                ticker = row.get('ticker') or row.get('symbol') or '?'
                lines.append(f"• {ticker}")
    else:
        for row in items[:6]:
            if isinstance(row, dict):
                label = str(row.get('label') or row.get('title') or row.get('ticker') or '—')[:100]
                lines.append(f"• {label}")

    warnings = payload.get('warnings') or []
    if warnings:
        lines.append(f"Warnings: {', '.join(str(w) for w in warnings[:4])}")
    return strip_stage_markers('\n'.join(lines))


def format_aihub_full(payloads: dict[str, dict[str, Any]]) -> str:
    lines = ['<b>🧭 AI Hub Full Summary</b>']

    brain = payloads.get('brain') or {}
    brain_summary = brain.get('summary') or {}
    brain_items = brain.get('items') or []
    actionable = brain_summary.get('actionable_candidates') or {}
    lines.append('<b>🧠 Brain</b>')
    if brain_items:
        row = brain_items[0]
        if isinstance(row, dict):
            sig = str(row.get('title') or row.get('summary') or row.get('text') or '—')[:120]
            lines.append(f'- {sig}')
    else:
        watch_n = len(actionable.get('watch_for_entry') or [])
        lines.append(f'- {watch_n} watch candidates' if watch_n else '- no brain signal cached')

    govt = payloads.get('govt') or {}
    govt_items = govt.get('items') or []
    govt_summary = govt.get('summary') or {}
    lines.append('<b>🏛 Govt</b>')
    if govt_items:
        row = govt_items[0]
        if isinstance(row, dict):
            lines.append(f"- {str(row.get('title') or row.get('headline') or row.get('summary') or '—')[:120]}")
    else:
        risk = govt_summary.get('top_risk') or govt_summary.get('policy_risk') or 'clean / no cached govt items'
        lines.append(f'- {risk}')

    scan = payloads.get('scan') or {}
    scan_summary = scan.get('summary') or {}
    scan_items = scan.get('items') or []
    live_scanner = scan.get('live_scanner') or []
    watchlist = scan.get('watchlist_candidates') or []
    lines.append('<b>📈 Scan</b>')
    lines.append(f"- live count: {scan_summary.get('live_scanner_count', len(live_scanner))}")
    scanner_names = [_ticker_from_row(r) for r in live_scanner[:3] if isinstance(r, dict)]
    watch_names = [_ticker_from_row(r) for r in watchlist[:3] if isinstance(r, dict)]
    if not scanner_names:
        scanner_names = [_ticker_from_row(r) for r in scan_items[:3] if isinstance(r, dict)]
    lines.append(f"- top scanner: {', '.join(scanner_names) if scanner_names else '—'}")
    lines.append(f"- top watchlist: {', '.join(watch_names) if watch_names else '—'}")

    market = payloads.get('market') or {}
    market_summary = market.get('summary') or {}
    mode = market.get('market_mode') or market_summary.get('market_mode') or 'RESEARCH_MODE'
    stale = market_summary.get('stale') or market_summary.get('is_stale')
    lines.append('<b>📊 Market</b>')
    lines.append(f'- mode: {mode}')
    lines.append(f"- {'stale' if stale else 'fresh'}")
    india = market_summary.get('india_context') or market_summary.get('context') or {}
    us_ctx = market_summary.get('us_context') or market_summary.get('global_context') or {}
    if isinstance(india, dict) and india:
        lines.append(f"- India: {str(india.get('headline') or india.get('status') or '—')[:80]}")
    if isinstance(us_ctx, dict) and us_ctx:
        lines.append(f"- US: {str(us_ctx.get('headline') or us_ctx.get('status') or '—')[:80]}")

    global_p = payloads.get('global') or {}
    global_summary = global_p.get('summary') or {}
    lines.append('<b>🌐 Global</b>')
    risk = resolve_global_risk_text(global_p)
    lines.append(f'- top risk: {risk}')
    commodities = global_summary.get('commodity_impacts') or global_summary.get('commodities') or []
    if isinstance(commodities, list) and commodities:
        parts = []
        for row in commodities[:3]:
            if isinstance(row, dict):
                parts.append(f"{row.get('commodity', '?')}: {row.get('stance', 'WATCH')}")
        if parts:
            lines.append(f"- commodities: {', '.join(parts)}")

    news = payloads.get('news') or {}
    news_items = news.get('items') or []
    lines.append('<b>📰 News</b>')
    if news_items:
        for row in news_items[:3]:
            if isinstance(row, dict):
                lines.append(f"- {str(row.get('title') or row.get('headline') or '—')[:100]}")
    else:
        lines.append('- no cached headlines')

    tv = payloads.get('tv') or {}
    tv_items = tv.get('items') or []
    lines.append('<b>📺 TV</b>')
    if tv_items:
        for row in tv_items[:3]:
            if isinstance(row, dict):
                lines.append(f"- {str(row.get('title') or row.get('headline') or '—')[:100]}")
    else:
        lines.append('- empty')

    reddit = payloads.get('reddit') or {}
    reddit_items = reddit.get('items') or []
    lines.append('<b>🤖 Reddit</b>')
    if reddit_items:
        for row in reddit_items[:3]:
            if isinstance(row, dict):
                lines.append(f"- {str(row.get('title') or row.get('headline') or '—')[:100]}")
    else:
        lines.append('- cache empty')

    calib = payloads.get('calib') or {}
    cal_summary = calib.get('summary') or {}
    cal = cal_summary.get('confidence_calibration') or {}
    if isinstance(cal, dict) and cal.get('summary'):
        cal = cal.get('summary') or cal
    recs = cal_summary.get('calibration_recommendations') or cal.get('recommendations') or []
    lines.append('<b>📊 Calib</b>')
    lines.append(f"- live resolved: {cal.get('live_resolved', cal.get('resolved_live', '—'))}")
    lines.append(f"- historical resolved: {cal.get('historical_resolved', cal.get('resolved_historical', '—'))}")
    if recs:
        first = recs[0]
        msg = first.get('message') if isinstance(first, dict) else str(first)
        lines.append(f"- warning: {str(msg)[:100]}")
    else:
        lines.append('- no calibration warnings')

    journal = payloads.get('journal') or {}
    journal_summary = journal.get('summary') or {}
    top_watch = journal_summary.get('top_watch') or []
    failed = journal_summary.get('failed_strong_warnings') or []
    lines.append('<b>📜 Journal</b>')
    lines.append(f"- mode: {journal.get('market_mode') or journal_summary.get('market_mode') or '—'}")
    if top_watch:
        names = [_ticker_from_row(r) for r in top_watch[:3] if isinstance(r, dict)]
        lines.append(f"- top watch: {', '.join(names)}")
    else:
        lines.append('- top watch: —')
    lines.append(f"- risk notes: {len(failed) if isinstance(failed, list) else 0}")

    lines.extend([
        '',
        'Use /today or /tomorrow for the short action list.',
    ])
    return strip_stage_markers('\n'.join(lines))


def _decision_short_instruction(payload: dict[str, Any]) -> str:
    if payload.get('ok') is not True:
        return str(payload.get('message') or 'Refresh reports for latest decision.')
    top = payload.get('top_pick')
    decision = payload.get('decision') or 'NO_CLEAN_CANDIDATE'
    if not top or decision == 'NO_CLEAN_CANDIDATE':
        return 'No clean candidate — review watchlist or wait for confluence.'
    action = str(top.get('action') or '').replace('_', ' ')
    ticker = top.get('ticker') or '—'
    if decision == 'BUY_CANDIDATE':
        return f'Monitor {ticker} ({action}) — confirm entry signals before acting.'
    return f'Watch {ticker} ({action}) — wait for confirmation, avoid chasing.'


def format_action_plan_telegram() -> str:
    """Compact action plan from stock decisions, brain payload, market/global, calibration."""
    from backend.analytics.aihub_tab_payloads import (
        build_brain_payload,
        build_global_payload,
        build_market_payload,
    )
    from backend.analytics.stock_decision_engine import build_stock_decision
    from backend.telegram.lazy_command_runner import DAILY_PACK_FILE, _load_json

    today = build_stock_decision(mode='today')
    tomorrow = build_stock_decision(mode='tomorrow')
    brain = build_brain_payload()
    market = build_market_payload(force=False)
    global_p = build_global_payload()
    pack = _load_json(DAILY_PACK_FILE)

    market_summary = (market.get('summary') or {})
    mode = (
        market.get('market_mode')
        or market_summary.get('market_mode')
        or pack.get('market_mode')
        or (pack.get('summary') or {}).get('market_mode')
        or 'RESEARCH_MODE'
    )
    stale_flag = market_summary.get('stale') or market_summary.get('is_stale')
    fresh_stale = 'Stale' if stale_flag else 'Fresh'
    main_risk = resolve_global_risk_text(global_p)

    brain_summary = brain.get('summary') or {}
    from backend.utils.config import DATA_DIR

    calib = {}
    calib_path = DATA_DIR / 'confidence_calibration_report.json'
    if calib_path.is_file():
        import json
        try:
            calib = json.loads(calib_path.read_text(encoding='utf-8'))
        except (OSError, json.JSONDecodeError):
            calib = {}
    calib_recs = []
    for rec in (calib.get('recommendations') or [])[:2]:
        if isinstance(rec, dict):
            calib_recs.append(str(rec.get('message') or rec.get('title') or rec)[:100])
        elif isinstance(rec, str):
            calib_recs.append(rec[:100])

    top = today.get('top_pick') if today.get('ok') else None
    decision = today.get('decision') if today.get('ok') else 'NO_CLEAN_CANDIDATE'

    lines = [
        '<b>📌 AstraEdge Action Plan</b>',
        '',
        '<b>Market state:</b>',
        f'• Mode: {mode}',
        f'• Fresh/Stale: {fresh_stale}',
        f'• Main risk: {main_risk}',
        '',
        '<b>Top candidate:</b>',
    ]

    if top and decision == 'BUY_CANDIDATE':
        action = str(top.get('action') or '').replace('_', ' ')
        lines.extend([
            f"• Ticker: {top.get('ticker', '—')}",
            f'• Action: {action}',
            f"• Score: {top.get('score', '—')}",
            f"• Confidence: {top.get('confidence', '—')}",
        ])
    elif top:
        action = str(top.get('action') or 'WATCH FOR ENTRY').replace('_', ' ')
        lines.append('No confirmed BUY candidate. Best watch-for-entry is...')
        lines.extend([
            f"• Ticker: {top.get('ticker', '—')}",
            f'• Action: {action}',
            f"• Score: {top.get('score', '—')}",
            f"• Confidence: {top.get('confidence', '—')}",
        ])
    else:
        lines.extend([
            'No confirmed BUY candidate. Best watch-for-entry is...',
            '• Ticker: —',
            '• Action: —',
            '• Score: —',
            '• Confidence: —',
        ])

    lines.extend(['', '<b>Why:</b>'])
    why_items = (top.get('why') or [])[:4] if top else []
    if why_items:
        for item in why_items:
            lines.append(f'• {item}')
    else:
        lines.append('• Review confluence sources before acting')

    lines.extend(['', '<b>Wait for:</b>'])
    wait_items = (top.get('confirmation_needed') or [])[:4] if top else [
        'price confirmation',
        'volume confirmation',
        'market not stale',
    ]
    for item in wait_items:
        lines.append(f'• {item}')

    avoid_rows = today.get('avoid') or [] if today.get('ok') else []
    actionable = brain_summary.get('actionable_candidates') or {}
    if not avoid_rows:
        avoid_rows = actionable.get('avoid') or []
    lines.extend(['', '<b>Avoid:</b>'])
    if avoid_rows:
        for row in avoid_rows[:5]:
            if not isinstance(row, dict):
                continue
            reason = (row.get('risk') or row.get('why') or ['weak signal'])
            if isinstance(reason, list):
                reason = reason[0] if reason else 'weak signal'
            lines.append(f"• {row.get('ticker', '?')} — {reason}")
    else:
        lines.append('• —')

    lines.extend([
        '',
        '<b>Today:</b>',
        f'• {_decision_short_instruction(today)}',
        '',
        '<b>Tomorrow:</b>',
        f'• {_decision_short_instruction(tomorrow)}',
    ])

    failed = brain_summary.get('failed_strong_warnings') or []
    if calib_recs or failed:
        lines.append('')
        if calib_recs:
            lines.append(f"Calibration: {calib_recs[0]}")
        if failed and isinstance(failed[0], dict):
            fw = failed[0]
            lines.append(f"Warning: {fw.get('ticker', '?')} — {str(fw.get('message', ''))[:80]}")

    return strip_stage_markers('\n'.join(lines))


def format_aihub_brain_full() -> str:
    """Full brain view — 10 compact sections from brain payload and stock decision engine."""
    from backend.analytics.aihub_tab_payloads import build_brain_payload
    from backend.analytics.stock_decision_engine import _load_sources, build_stock_decision

    brain = build_brain_payload()
    today = build_stock_decision(mode='today')
    tomorrow = build_stock_decision(mode='tomorrow')
    sources = _load_sources()
    brain_summary = brain.get('summary') or {}

    market = sources.get('market') or {}
    market_summary = market.get('summary') or {}
    mode = market.get('market_mode') or market_summary.get('market_mode') or '—'
    stale = 'Stale' if (market_summary.get('stale') or market_summary.get('is_stale')) else 'Fresh'
    global_p = sources.get('global') or {}
    risk = resolve_global_risk_text(global_p)
    intel = brain_summary.get('intelligence') or {}
    exec_summary = intel.get('executive_summary') or intel.get('summary') or ''

    lines = ['<b>🧠 AstraEdge Brain — Full</b>', '']

    lines.extend(['<b>1. Market read</b>', f'• Mode: {mode} · {stale}', f'• Risk: {risk}'])
    if exec_summary:
        lines.append(f'• {str(exec_summary)[:180]}')

    actionable = brain_summary.get('actionable_candidates') or {}
    buy_n = len(actionable.get('buy_candidate') or [])
    watch_n = len(actionable.get('watch_for_entry') or [])
    avoid_n = len(actionable.get('avoid') or [])
    fc = sources.get('final_confidence') or {}
    lines.extend([
        '',
        '<b>2. Actionability</b>',
        f'• Buy candidates: {buy_n} · Watch: {watch_n} · Avoid: {avoid_n}',
        f"• Active mode: {fc.get('active_mode') or '—'}",
    ])

    top = today.get('top_pick') if today.get('ok') else None
    lines.extend(['', '<b>3. Top candidate</b>'])
    if top:
        action = str(top.get('action') or '—').replace('_', ' ')
        lines.append(
            f"• {top.get('ticker')} — {action} · score {top.get('score')} · {top.get('confidence')}"
        )
    else:
        lines.append('• No clean candidate in latest today decision')

    ranked = (today.get('ranked_candidates') or [])[:5] if today.get('ok') else []
    lines.extend(['', '<b>4. Ranked candidates</b>'])
    if ranked:
        for row in ranked:
            if isinstance(row, dict):
                action = str(row.get('action') or '—').replace('_', ' ')
                lines.append(f"• {row.get('ticker')} — {action} · {row.get('score')}")
    else:
        lines.append('• —')

    lines.extend(['', '<b>5. Reasons/supports</b>'])
    if top:
        for w in (top.get('why') or [])[:4]:
            lines.append(f'• {w}')
        supports = top.get('supports') or []
        if supports:
            lines.append(f"• Supports: {', '.join(str(s) for s in supports)}")
    else:
        lines.append('• Review /today for breakdown')

    lines.extend(['', '<b>6. Risks/blocks</b>'])
    risk_lines = 0
    if top:
        for r in (top.get('risk') or [])[:4]:
            lines.append(f'• {r}')
            risk_lines += 1
    for fw in (brain_summary.get('failed_strong_warnings') or [])[:3]:
        if isinstance(fw, dict):
            lines.append(f"• {fw.get('ticker', '?')} — {str(fw.get('message', 'failed strong signal'))[:80]}")
            risk_lines += 1
    if not risk_lines:
        lines.append('• No major blocks flagged')

    calib = sources.get('calibration') or {}
    recs = calib.get('recommendations') or []
    lines.extend(['', '<b>7. Calibration</b>'])
    if recs:
        for rec in recs[:3]:
            if isinstance(rec, dict):
                lines.append(f"• {str(rec.get('message') or rec.get('title') or rec)[:100]}")
            elif isinstance(rec, str):
                lines.append(f'• {rec[:100]}')
    else:
        lines.append('• No calibration warnings')

    memory = sources.get('memory') or {}
    learning = memory.get('learning') or {}
    overall = learning.get('overall') or {}
    stats = memory.get('stats') or {}
    lines.extend([
        '',
        '<b>8. Memory learning</b>',
        f"• Win rate: {format_memory_win_rate(overall)} · W/L: {overall.get('wins', 0)}/{overall.get('losses', 0)}",
        f"• Predictions: {stats.get('predictions') or overall.get('total_predictions') or '—'}",
    ])

    broker = sources.get('broker') or {}
    our_vs = broker.get('our_vs_broker') or {}
    comparisons = our_vs.get('comparisons') or our_vs.get('rows') or []
    agree = sum(1 for r in comparisons if isinstance(r, dict) and r.get('agreement'))
    conflict = sum(1 for r in comparisons if isinstance(r, dict) and r.get('conflict'))
    lines.extend(['', '<b>9. Broker/external confluence</b>', f'• Agreement/conflict: {agree}/{conflict}'])
    shown = 0
    for row in comparisons[:3]:
        if isinstance(row, dict):
            ticker = row.get('ticker') or row.get('symbol') or '?'
            direction = row.get('direction') or row.get('broker_stance') or row.get('stance') or '—'
            lines.append(f'• {ticker} · {direction}')
            shown += 1
    if not shown:
        tw = sources.get('tomorrow_watchlist') or {}
        ext = tw.get('external_evidence') or tw.get('top_watchlist') or []
        for row in (ext if isinstance(ext, list) else [])[:2]:
            if isinstance(row, dict):
                lines.append(f"• {row.get('ticker') or row.get('symbol') or '?'} · external evidence")

    lines.extend(['', '<b>10. Confirmation checklist</b>'])
    if top:
        for c in (top.get('confirmation_needed') or [])[:5]:
            lines.append(f'• {c}')
    else:
        lines.append('• Price/volume confirmation before entry')
        lines.append('• Market data fresh')

    tom_top = tomorrow.get('top_pick') if tomorrow.get('ok') else None
    if tom_top and tom_top.get('ticker') != (top or {}).get('ticker'):
        lines.append(f"• Tomorrow watch: {tom_top.get('ticker')} ({str(tom_top.get('action') or '').replace('_', ' ')})")

    return strip_stage_markers('\n'.join(lines))


def format_status_text() -> str:
    lines = ['<b>📡 Status</b>']
    telegram_enabled = False
    try:
        from backend.utils.config import IS_LOCAL_DEV, LOCAL_ONLY
        from backend.utils.telegram_guard import is_telegram_listener_enabled, is_telegram_send_enabled

        mode = 'local' if (LOCAL_ONLY or IS_LOCAL_DEV) else 'railway/production'
        lines.append(f'Mode: <code>{mode}</code>')
        listener_on = is_telegram_listener_enabled()
        sends_on = is_telegram_send_enabled()
        telegram_enabled = listener_on and sends_on
        lines.append(f'Telegram: {"enabled" if telegram_enabled else "disabled"}')
    except Exception:
        lines.append('Mode: unknown (config unavailable)')
        lines.append('Telegram: unknown')

    try:
        from backend.telegram.lazy_command_runner import DAILY_PACK_FILE, _load_json

        pack = _load_json(DAILY_PACK_FILE)
        if pack:
            summary = pack.get('summary') or {}
            market_mode = (
                pack.get('market_mode')
                or summary.get('market_mode')
                or (pack.get('final_confidence') or {}).get('active_mode')
                or '—'
            )
            report_time = (
                pack.get('generated_at')
                or pack.get('package_generated_at')
                or summary.get('generated_at')
                or '—'
            )
            lines.append(f'Market mode: <code>{market_mode}</code>')
            lines.append(f'Latest report: {report_time}')
        else:
            lines.append('Market mode: unavailable')
            lines.append('Latest report: unavailable')
    except Exception:
        lines.append('Latest report: unavailable')

    try:
        from backend.telegram.lazy_command_runner import (
            E2E_REPORT,
            LIVE_SMOKE_REPORT,
            LOCAL_READINESS_REPORT,
            QA_REPORT_PATH,
            _cache_age_minutes,
            _load_json,
        )

        qa_sources = (
            ('telegram_qa', QA_REPORT_PATH),
            ('live_smoke', LIVE_SMOKE_REPORT),
            ('local_readiness', LOCAL_READINESS_REPORT),
            ('gui_e2e', E2E_REPORT),
        )
        qa_line = 'Last QA: no report cached'
        for label, path in qa_sources:
            qa = _load_json(path)
            if qa:
                status = (
                    'ok'
                    if qa.get('ok') is True or qa.get('ready') is True
                    else str(qa.get('status') or 'unknown')
                )
                age = _cache_age_minutes(path)
                age_txt = format_cache_age_label(age, timestamp=file_timestamp_iso(path))
                qa_line = f'Last QA: <code>{status}</code> · {label} ({age_txt})'
                break
        lines.append(qa_line)
    except Exception:
        lines.append('Last QA: unavailable')

    return strip_stage_markers('\n'.join(lines))
