"""Intelligence alignment helpers."""
